# Nine Men's Morris
Nine Men's Morris is a strategy board game for two players. <br>
Online version is available at https://yadav-rahul.github.io/Nine-Mens-Morris/.

##Instructions
[Refer here](https://en.wikipedia.org/wiki/Nine_Men%27s_Morris)